
def kafka_conf():
  return {}

